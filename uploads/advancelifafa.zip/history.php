
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <title>history</title>
</head><meta name="robots" content="noindex, follow"> <meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <!--<link rel="stylesheet" href="https://CashbackBooster.in/css/style1.css"> <link rel="stylesheet" href="https://CashbackBooster.in/css/promo1.css">--> <link href="https://fonts.googleapis.com/css?family=Nunito:400,700&display=swap" rel="stylesheet"> <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"> </head> <body> <section class="promo-main-section"><br> <div class="container1"> <div class="container1"> </div> </div> <div class="row justify-content-center"> <div class="col-lg-8 col-md-9"> <div class="promo-offer-block rounded bg-white mb-4"> <center><br> 		 <div class="container"> <div class="limiter">


    <?php
    $num=$_POST['number'];
    $dr="ban/$num/$num.txt";
            if(file_exists($dr)){echo"YOUR ACCOUNT BANNED";}else{
    $fi="user/$num/history/$num.txt";
    $oldin=file_get_contents($fi);
    echo"$oldin";}
    ?>
