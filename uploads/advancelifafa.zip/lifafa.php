<?php

$id1=$_GET['lifafa'];

$file="lifafa/$id1/$id1.json";

if(file_exists($file)){}else{
echo"Invalid lifafa Id";
return;
}
$data=file_get_contents($file);
$json=json_decode($data,true);
$title=$json['title'];
$peruser=$json['peruser'];
$user=$json['user'];
$url=$json['url'];
$number=$json['number'];
$code=$json['code'];
$channel=$json['channel'];
$totalclaim=file_get_contents("lifafa/$id1/claim$id1.txt");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
  <title><?php echo $title;?></title>
</head><meta name="robots" content="noindex, follow"> <meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <!--<link rel="stylesheet" href="https://CashbackBooster.in/css/style1.css"> <link rel="stylesheet" href="https://CashbackBooster.in/css/promo1.css">--> <link href="https://fonts.googleapis.com/css?family=Nunito:400,700&display=swap" rel="stylesheet"> <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"> </head> <body> <section class="promo-main-section"><br> <div class="container1"> <div class="container1"> </div> </div> <div class="row justify-content-center"> <div class="col-lg-8 col-md-9"> <div class="promo-offer-block rounded bg-white mb-4"> <center><br> 		 <div class="container"> <div class="limiter">
  <h2 class="active"><font color="black">LIFAFA</h2>

  <center>

 <?php

 if(isset($_GET['id'])){
 $nameid="id";
 $valueid=$_GET['id'];
 $namename="name";
 $fname=$_GET['first_name'];
 $lname=$_GET['last_name'];
 $namevalue="$fname$lname";
 setcookie($nameid,$valueid,time() + (86400 * 300),"/");
 setcookie($namename, $namevalue, time() + (86400 * 300), "/");


 	$url6='https://api.telegram.org/bot5222669849:AAHiiaYXh1RHE3SH7H3KhwfJxQcSKFtTDhQ/getChatMember?user_id='.$valueid.'&chat_id=@'.$channel.'';

 		$ch6=curl_init();
 curl_setopt($ch6,CURLOPT_URL,$url6);
 curl_setopt($ch6,CURLOPT_POST,1);
     curl_setopt($ch6,CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch6,CURLOPT_SSL_VERIFYPEER,false);


     $output6=curl_exec($ch6);

     curl_close($ch6);

     $json6=json_decode($output6,true);
     $ok=$json6['result']['status'];
echo"$output6";

     if($ok=='left'){
       echo"FIRST JOIN THIS CHANNEL AFTER CLAIM LIFAFA <BR><meta http-equiv='refresh' content='3;url=$url'>";
     }elseif($output6=='{"ok":false,"error_code":400,"description":"Bad Request: user not found"}'){echo"FIRST MAKE BOT ADMIN";}
     else{

     	$uyd="lifafa/$id1/claim$id1.txt";
 $tre=file_get_contents($uyd);
 if($tre==$user){echo"LIFAFA CLAIMED";}else{
 if($_GET['submit']=='claim'){
    $code1=$_GET['codee'];
 if($code==$code1){
 $num=$_GET['num'];
 $bannum="user/$number/ban/$num.txt";
 if(file_exists($bannum)){echo"YOU ARE BANNED";}else{
 $uy="lifafa/$id1";
 mkdir($uy);
 $claimfile="lifafa/$id1/$id1$num";

 if(file_exists($claimfile)){

 echo " You already claimed lifafa ";
 echo"<meta http-equiv='refresh' content='2;url=$url'>";
 return;
 }
 fopen($claimfile,'a');
 $claim6=$totalclaim+1;
 file_put_contents("lifafa/$id1/claim$id1.txt",$claim6);
 file_put_contents("lifafa/$id1/$id1$num.txt",$num);

 echo " <h2> Congratulation You claim $peruser ₹ ";
 //gateway here

 $urlencc="$title LIFAFA BY I AM ANKIT PANEL ";
 $urlen=urlencode($urlencc);
 $url2="https://job2all.xyz/api/index.php?mid=&mkey=&guid=&mob=$num&amount=$peruser&info=$urlen";


 $ch=curl_init();
 curl_setopt($ch,CURLOPT_URL,$url2);
 curl_setopt($ch,CURLOPT_POST,1);
     curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);


     $output=curl_exec($ch);

     curl_close($ch);

   echo"<meta http-equiv='refresh' content='3;url=$url'>";

 }}
 else{echo"ACCESS CODE WRONG<meta http-equiv='refresh' content='3;url=$url'>";}
 }else{echo'
 <form method="" action="GET">

 <input  type="number" name="num" id="num" class="input" placeholder="Enter Your Number" autocomplete="off" required/>
 <input  type="text" name="codee" id="num"  class="input"placeholder="Enter Access Code" autocomplete="off" required/>

   <input type="text" name="" id="num"class="input" value="Amount : &#8377 '.$peruser.'" disabled />
   <input type="text" name="" id="num" class="input"value="'.$url.'" disabled/><br />
   <input type="hidden" name="lifafa"  value="'.$id1.'" /><br />

   <input type="submit" name="submit" class="submit" value="claim" />
 </form>';

 }}
 echo"<br>$tre / $user";
 }


 }


 else{
 	if(isset($_COOKIE["id"])){
 		$id=$_COOKIE["id"];
 		$name=$_COOKIE["name"];



 		$url6='https://api.telegram.org/bot5222669849:AAHiiaYXh1RHE3SH7H3KhwfJxQcSKFtTDhQ/getChatMember?user_id='.$id.'&chat_id=@'.$channel.'';

 		$ch6=curl_init();
 curl_setopt($ch6,CURLOPT_URL,$url6);
 curl_setopt($ch6,CURLOPT_POST,1);
     curl_setopt($ch6,CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch6,CURLOPT_SSL_VERIFYPEER,false);


     $output6=curl_exec($ch6);

     curl_close($ch6);
     $json6=json_decode($output6,true);
     $ok=$json6['result']['status'];


 if($ok=='left'){
       echo"FIRST JOIN THIS CHANNEL AFTER CLAIM LIFAFA <BR><meta http-equiv='refresh' content='3;url=$url'>";
     }elseif($output6=='{"ok":false,"error_code":400,"description":"Bad Request: user not found"}'){echo"FIRST MAKE BOT ADMIN";}
     else{

     	$uyd="lifafa/$id1/claim$id1.txt";
 $tre=file_get_contents($uyd);
 if($tre==$user){echo"LIFAFA CLAIMED";}else{
 if($_GET['submit']=='claim'){
    $code1=$_GET['codee'];
 if($code==$code1){
 $num=$_GET['num'];
 $bannum="user/$number/ban/$num.txt";
 if(file_exists($bannum)){echo"YOU ARE BANNED";}else{
 $uy="lifafa/$id1";
 mkdir($uy);
 $claimfile="lifafa/$id1/$id1$num";

 if(file_exists($claimfile)){

 echo " You already claimed lifafa ";
 echo"<meta http-equiv='refresh' content='2;url=$url'>";
 return;
 }
 fopen($claimfile,'a');
 $claim6=$totalclaim+1;
 file_put_contents("lifafa/$id1/claim$id1.txt",$claim6);
 file_put_contents("lifafa/$id1/$id1$num.txt",$num);

 echo " <h2> Congratulation You claim $peruser ₹ ";
 //gateway here

 $urlencc="$title LIFAFA BY I AM ANKIT PANEL ";
 $urlen=urlencode($urlencc);
 $url2="https://job2all.xyz/api/index.php?mid=&mkey=&guid=&mob=$num&amount=$peruser&info=$urlen";


 $ch=curl_init();
 curl_setopt($ch,CURLOPT_URL,$url2);
 curl_setopt($ch,CURLOPT_POST,1);
     curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);


     $output=curl_exec($ch);

     curl_close($ch);

   echo"<meta http-equiv='refresh' content='3;url=$url'>";

 }}
 else{echo"ACCESS CODE WRONG<meta http-equiv='refresh' content='3;url=$url'>";}
 }else{echo'
 <form method="" action="GET">

 <input  type="number" name="num" id="num"  class="input" placeholder="Enter Your Number" autocomplete="off" required/>
 <input  type="text" name="codee" id="num" class="input" placeholder="Enter Access Code" autocomplete="off" required/>

   <input type="text" class="input"name="" id="num" value="Amount : &#8377 '.$peruser.'" disabled />
   <input type="text" class="input" name="" id="num" value="'.$url.'" disabled/><br />
   <input type="hidden" name="lifafa"  value="'.$id1.'" /><br />

   <input type="submit" name="submit" class="submit" value="claim" />
 </form>';

 }}
 echo"<br>$tre / $user";





     }

 	}else{
 		echo'  <br>  <br>  <br><script async src="https://telegram.org/js/telegram-widget.js?15" data-telegram-login="XYZ_ROBOT_BOT" data-size="large" data-auth-url="http://opscript.rf.gd/v/lifafa.php?lifafa='.$id1.'" data-request-access="write"></script>
         
         <br>  <br>  <br>  <br>  <br>  <br>
         <a href="###" >  <input type="submit" name="submit" class="submit" value="CONTINUE WITH BOT" </a>
         ';


 	}




 }
  ?>
<br>



  </form>

</div> </div> </form> </div> <!-- DESCRIPTION --><!-- DESCRIPTION -->  </div> </div> </div> </div> </div> </div> </div> </div> <br><br> </section> <style> body{ margin: 0; padding: 0; } .promo-main-section { height:100%; background-image: linear-gradient( 65.9deg, rgba(85,228,224,1) 5.5%, rgba(75,68,224,0.74) 54.2%, rgba(64,198,238,1) 55.2%, rgba(177,36,224,1) 98.4% ); background-size: 200% 200%; animation: Animation 8s ease infinite; max-width:100%; /* Maximum width */ margin: 0 auto; /* Center it */ } @keyframes Animation { 0%{background-position:59% 100%} 50%{background-position:100% 10%} 70%{background-position:10% 100%} } .promo-main-section .container{ position:relative ; /* Position the background text */ bottom: 0; /* At the bottom. Use top:0 to append it to the top */ background: rgb(0, 0, 0); /* Fallback color */ background: rgba(0, 0, 0, 0.4); /* Black background with 0.5 opacity */ color: #f1f1f1; /* Grey text */ width: 340px; /* Full width */ padding: ; /* Some padding */ height:700px; border-radius:15px; box-shadow: 1px 1px 46px; border:1px solid; } .inp{ width: 80%; height: 40px; border-radius:5px; outline:0; border:1px solid white; text-align:center; font-size:16px; position:relative ; /* Position the background text */ bottom: 0; /* At the bottom. Use top:0 to append it to the top */ background: rgb(0, 0, 0); /* Fallback color */ background: rgba(0, 0, 0, 0.3); /* Black background with 0.5 opacity */ color: #f1f1f1; /* Grey text */ padding: ; /* Some padding */ font-weight: bold; } ::placeholder{ text-align:center; color:white; } .btn{ width: 70%; height:45px; background: blue; color:#fff; border:0; border-radius: 30px; font-weight: bold; border:1px solid white; outline:0; } .btn:focus{ background: #00ccff; } input:focus::-webkit-input-placeholder { color: #999; } input:focus{ color:white; } .a {
    color: #fff;
    background: rgb(54, 119, 255, 0.6);
    border-radius: 5px;
    padding: 7px;
    text-align: center;
    width: 100% !important;
    margin-top: 100px !important;
    border: 1px rgb(54, 119, 255) solid;
    text-decoration: none;
}
.img{ height:80px; width: 70px; background-size: cover; border-radius: 50%; border:1px solid; padding: 2px; margin-top: 50px; border: 1px solid white; } .btn-join{ background: #1da0fd; width: 80%; height: 40px; margin-top: 7px; border-radius: 50px; outline: 0; border:1px solid blue; color: white; opacity: 90%; font-weight: bold; } .btn-join:focus{ background: black; } .box{ width: 90%; height: 100px; background:#20c8f4; border-radius: 5px; opacity:100%; color: black; } .button{ width: 70%; height:45px; background: blue; color:#fff; border:0; border-radius: 30px; font-weight: bold; border: 1px solid white; outline:0; } .button:focus{ background: #00ccff; } a{ text-decoration: none; color:white; } </style> </center> <script src='demo-to-prevent-copy-paste-on-blogger_files/googleapis.js'></script><script type='text/javascript'> if(typeof document.onselectstart!="undefined" ) {document.onselectstart=new Function ("return false" ); } else{document.onmousedown=new Function ("return false" );document.onmouseup=new Function ("return false"); } </script> </body> </html>