
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bree+Serif&family=Montserrat:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css">
    <title>Ankit</title>
</head><meta name="robots" content="noindex, follow"> <meta charset="utf-8"> <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> <!--<link rel="stylesheet" href="https://CashbackBooster.in/css/style1.css"> <link rel="stylesheet" href="https://CashbackBooster.in/css/promo1.css">--> <link href="https://fonts.googleapis.com/css?family=Nunito:400,700&display=swap" rel="stylesheet"> <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"> </head> <body> <section class="promo-main-section"><br> <div class="container1"> <div class="container1"> </div> </div> <div class="row justify-content-center"> <div class="col-lg-8 col-md-9"> <div class="promo-offer-block rounded bg-white mb-4"> <center><br> 		 <div class="container"> <div class="limiter">
  <h2 class="active"><font color="black">VERIFY PAYMENT</h2>

  <center>
  <?php

    if(isset($_POST['submit']))
    {


       $num=$_POST['number'];


 $bal=file_get_contents("user/$num/$num.txt");
 $json=json_decode($bal,true);
 $balance=$json['balance'];
 $number=$json['number'];
 $q=$json['q'];
 $email=$json['email'];
 $pwd=$json['password'];




 $orderid=$_POST['order_id'];
 if(!$orderid){
 echo " Invalid reqest ";
 return;
 }

 $dt="user/$num/add/$orderid.txt";
 if(file_exists($dt)){echo"PAPA SE HOSYARI NAHI";}else{
    $dt1="user/$num/add";
    mkdir($dt1);
    fopen("user/$num/add/$orderid.txt",'a');
 file_put_contents("user/$num/add/$orderid.txt",$orderid);


 $url6="https://full2sms.in/status_order.php?order_id=$orderid";


 		$ch6=curl_init();
 curl_setopt($ch6,CURLOPT_URL,$url6);
 curl_setopt($ch6,CURLOPT_POST,1);
     curl_setopt($ch6,CURLOPT_RETURNTRANSFER,1);
      curl_setopt($ch6,CURLOPT_SSL_VERIFYPEER,false);


     $output6=curl_exec($ch6);

     curl_close($ch6);



 $json=json_decode($output6,true);
 $data=$json['status'];
 $amo3=$json['amount'];
 $amo1=(10*$amo3);
 $amo=$amo1/11;
 if($data=="success"){

 //success

 $avbal=$balance+$amo;
 $avbal1='{"number":"'.$num.'","email":"'.$email.'","password":"'.$pwd.'","q":"'.$q.'","balance":"'.$avbal.'"}' ;
 $uy="user/$num/history" ;
 mkdir($uy)  ;
 $fi="user/$num/history/$num.txt";
 $oldin=file_get_contents($fi);
 $in1=''.$oldin.'{"type":"add","amount":"'.$amo.'"}';
 $r="user/$num/history";
 mkdir($r);

 fopen("user/$num/history/$num.txt",'a');
 file_put_contents("user/$num/history/$num.txt",$in1);

     file_put_contents("user/$num/$num.txt",$avbal1);
 echo " TXN || SUCESS";

 unset($_SESSION["orderid"]);

 }else{echo"$output6";}
       }

    }if(!isset($_POST['submit'])){
       $orderid=$_GET['order_id'];
      
       echo'

       <form action="" method="POST"
  >

  <input type="hidden" name="order_id" value="'.$orderid.'">

  <BR>ENETER NUMBER FOR UPDATE WALLET<BR>
    <input type="number" name="number" class="input" placeholder="ENTER REJESTER NUMBER " actucomplete="off" required><br>
    <input type="submit" class="submit" name="submit"value="submit">
    <br>




       ';












 }?>
<br>






</div> </div> </form> </div> <!-- DESCRIPTION --><!-- DESCRIPTION -->  </div> </div> </div> </div> </div> </div> </div> </div> <br><br> </section> <style> body{ margin: 0; padding: 0; } .promo-main-section { height:100%; background-image: linear-gradient( 65.9deg, rgba(85,228,224,1) 5.5%, rgba(75,68,224,0.74) 54.2%, rgba(64,198,238,1) 55.2%, rgba(177,36,224,1) 98.4% ); background-size: 200% 200%; animation: Animation 8s ease infinite; max-width:100%; /* Maximum width */ margin: 0 auto; /* Center it */ } @keyframes Animation { 0%{background-position:59% 100%} 50%{background-position:100% 10%} 70%{background-position:10% 100%} } .promo-main-section .container{ position:relative ; /* Position the background text */ bottom: 0; /* At the bottom. Use top:0 to append it to the top */ background: rgb(0, 0, 0); /* Fallback color */ background: rgba(0, 0, 0, 0.4); /* Black background with 0.5 opacity */ color: #f1f1f1; /* Grey text */ width: 340px; /* Full width */ padding: ; /* Some padding */ height:700px; border-radius:15px; box-shadow: 1px 1px 46px; border:1px solid; } .inp{ width: 80%; height: 40px; border-radius:5px; outline:0; border:1px solid white; text-align:center; font-size:16px; position:relative ; /* Position the background text */ bottom: 0; /* At the bottom. Use top:0 to append it to the top */ background: rgb(0, 0, 0); /* Fallback color */ background: rgba(0, 0, 0, 0.3); /* Black background with 0.5 opacity */ color: #f1f1f1; /* Grey text */ padding: ; /* Some padding */ font-weight: bold; } ::placeholder{ text-align:center; color:white; } .btn{ width: 70%; height:45px; background: blue; color:#fff; border:0; border-radius: 30px; font-weight: bold; border:1px solid white; outline:0; } .btn:focus{ background: #00ccff; } input:focus::-webkit-input-placeholder { color: #999; } input:focus{ color:white; } .a {
    color: #fff;
    background: rgb(54, 119, 255, 0.6);
    border-radius: 5px;
    padding: 7px;
    text-align: center;
    width: 100% !important;
    margin-top: 100px !important;
    border: 1px rgb(54, 119, 255) solid;
    text-decoration: none;
}
.img{ height:80px; width: 70px; background-size: cover; border-radius: 50%; border:1px solid; padding: 2px; margin-top: 50px; border: 1px solid white; } .btn-join{ background: #1da0fd; width: 80%; height: 40px; margin-top: 7px; border-radius: 50px; outline: 0; border:1px solid blue; color: white; opacity: 90%; font-weight: bold; } .btn-join:focus{ background: black; } .box{ width: 90%; height: 100px; background:#20c8f4; border-radius: 5px; opacity:100%; color: black; } .button{ width: 70%; height:45px; background: blue; color:#fff; border:0; border-radius: 30px; font-weight: bold; border: 1px solid white; outline:0; } .button:focus{ background: #00ccff; } a{ text-decoration: none; color:white; } </style> </center> <script src='demo-to-prevent-copy-paste-on-blogger_files/googleapis.js'></script><script type='text/javascript'> if(typeof document.onselectstart!="undefined" ) {document.onselectstart=new Function ("return false" ); } else{document.onmousedown=new Function ("return false" );document.onmouseup=new Function ("return false"); } </script> </body> </html>
