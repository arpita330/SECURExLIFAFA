if (""+params+""=="undefined"){
Bot.sendMessage("*🥰 Hello "+user.first_name +"\n\n😎Welcome to User Verification Bot😎\n\n🙂Join @I_AMANKIT_SCRIPTER 🙂\n\n🥲You are Redirected from Website🥲*");
var txt =
  "*👉Join Our Offical Channel (For More Update )*"
var button = [
  [
    {
      title: "🎁Open Channel🎁",
      url:
        "https://t.me/i_amankit_scripter"
    }
  ],
  
]
Bot.sendInlineKeyboard(button, txt, { is_reply: false })
}else{
Bot.sendMessage("*🥰 Hello "+user.first_name+"  🥰\n\n😎Welcome to User Verification Bot😎*");
var txt =
  "*👉Click Open Claim Link to Claim Lifafa*"
var button = [
  [
    {
      title: "🎁Open Claim Link🎁",
      url:
        "http://example.com/lifafa.php/?lifafa="+params+"&id="+user.telegramid+""
    }
  ],
  
]
Bot.sendInlineKeyboard(button, txt, { is_reply: false })



}